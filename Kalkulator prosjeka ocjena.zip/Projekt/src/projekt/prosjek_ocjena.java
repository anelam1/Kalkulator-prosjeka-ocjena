package projekt;

import javax.swing.*;
import java.awt.event.*;

public class prosjek_ocjena  {

    int Total;
    int NumberOfMarks;
    private JTextField jtxtMark;
    private JTextField jtxtAverage;
    private JRadioButton jrbResult;
    private JButton jbtnOk;
    private JButton jbtnAverage;
    private JButton jbtnReset;
    private JButton jbtnExit;
    private JList jList1;
    private JLabel jlblMark;
    private JLabel jlblResult;
    private JPanel panelMain;
    private void WindowActivated(java.awt.event.WindowEvent evt) {
        Total = 0;
        NumberOfMarks = 0;
        jbtnAverage.setEnabled(false);
        jrbResult.setEnabled(false);
        jbtnReset.setEnabled(false);
        jlblResult.setVisible(false);
        jtxtAverage.setVisible(false);
        jlblMark.setVisible(false);

    }

    public prosjek_ocjena() {

        jbtnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int c = JOptionPane.showConfirmDialog(null, "All system down", "System Down",
                        JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
                if (c == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }

            }
        });
        jbtnReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jbtnAverage.setEnabled(false);
                jrbResult.setEnabled(false);
                jbtnReset.setEnabled(false);
                jlblResult.setText(null);
                jtxtAverage.setText(null);
                jlblMark.setText(null);
                jtxtMark.setEnabled(true);
                jtxtAverage.setVisible(false);
                jbtnOk.setEnabled(true);
                //Number.clear();
                //jList1.setModel(Number);
            }
        });
        DefaultListModel Number;
        Number = new DefaultListModel();
        jbtnOk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int num1 = Integer.parseInt(jtxtMark.getText());
                Number.addElement(num1);
                jList1.setModel(Number);
                Total=0;
                NumberOfMarks=0;
                Total = Total + num1;
                NumberOfMarks = NumberOfMarks + 1;
                jbtnAverage.setEnabled(true);
                jtxtMark.setText(null);
                jlblMark.setVisible(true);
                jtxtAverage.setVisible(true);

                int count = jList1.getModel().getSize();
                if (count == 12) {
                    jtxtMark.setEnabled(false);
                    jbtnOk.setEnabled(false);
                    jrbResult.setEnabled(true);
                }
            }
        });

        jbtnAverage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Double Average;
                Average = Double.valueOf(Total/NumberOfMarks);
                Float Answer = Float.valueOf(String.valueOf(Total / 12));
                jtxtAverage.setText(String.valueOf(Average));
                jtxtAverage.setEnabled(true);
                jtxtMark.setEnabled(false);
                jbtnOk.setEnabled(false);
                jrbResult.setEnabled(true);
                jbtnReset.setEnabled(true);

                if (Average >= 4.5) {
                    jlblResult.setText("ODLIČAN");
                }
                if (Average < 4.5 & Average >= 3.5) {
                    jlblResult.setText("VRLO DOBAR");
                }
                if (Average < 3.5 & Average >= 2.5) {
                    jlblResult.setText("DOBAR");
                }
                if (Average < 2.5 & Average >= 1.5) {
                    jlblResult.setText("DOVOLJAN");
                }
                if (Average < 1.5) {
                    jlblResult.setText("NEDOVOLJAN");
                }
            }
        });
        jrbResult.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jlblResult.setVisible(true);
            }
        });
        jtxtMark.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                char c = e.getKeyChar();
                if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_DELETE))) {

                    e.consume();
                }
            }
        });
        jtxtAverage.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
                char c = e.getKeyChar();
                if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_DELETE))) {

                    e.consume();
                }
            }
        });
    }
    public static void main(String[] args){
        JFrame frame = new JFrame("prosjek");
        frame.setContentPane(new prosjek_ocjena().panelMain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setSize(1080,400);

    }
}
